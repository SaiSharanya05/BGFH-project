# AI Content Detector

Free AI powered app to detect whether the contect you are reading/viewing is AI generated or not

[Click Here](https://ai-content-detector.netlify.app/) to use it!
